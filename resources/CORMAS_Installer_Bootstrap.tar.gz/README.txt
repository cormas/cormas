CORMAS for Pharo 6.x
